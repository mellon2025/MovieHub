import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/movie.dart';
import '../services/api_service.dart';
import 'package:cached_network_image/cached_network_image.dart';

class DetailsScreen extends StatefulWidget {
  final Movie movie;
  DetailsScreen({required this.movie});

  @override
  _DetailsScreenState createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  final ApiService api = ApiService();
  String? youtubeKey;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadTrailer();
  }

  Future<void> _loadTrailer() async {
    final key = await api.fetchYoutubeTrailerKey(widget.movie.id);
    setState(() {
      youtubeKey = key;
      loading = false;
    });
  }

  void _openTrailer() async {
    if (youtubeKey == null) return;
    final url = 'https://www.youtube.com/watch?v=$youtubeKey';
    if (await canLaunch(url)) {
      await launch(url);
    }
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.movie;
    return Scaffold(
      appBar: AppBar(title: Text(m.title)),
      body: SingleChildScrollView(
        child: Column(
          children: [
            m.backdropPath.isNotEmpty
                ? CachedNetworkImage(imageUrl: 'https://image.tmdb.org/t/p/w780${m.backdropPath}', width: double.infinity, height: 200, fit: BoxFit.cover)
                : Container(height: 200, color: Colors.grey),
            Padding(
              padding: EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(m.title, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Text('تاريخ الإصدار: ${m.releaseDate}'),
                  SizedBox(height: 12),
                  Text(m.overview),
                  SizedBox(height: 20),
                  loading
                      ? CircularProgressIndicator()
                      : youtubeKey != null
                          ? ElevatedButton.icon(onPressed: _openTrailer, icon: Icon(Icons.play_arrow), label: Text('مشاهدة التريلر'))
                          : Text('لا يوجد تريلر متاح'),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}