import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/movie.dart';
import '../widgets/movie_card.dart';
import 'details_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService api = ApiService();
  List<Movie> movies = [];
  bool loading = true;
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      movies = await api.fetchPopular();
    } catch (e) {
      movies = [];
    }
    setState(() => loading = false);
  }

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) return _load();
    setState(() => loading = true);
    try {
      movies = await api.search(q);
    } catch (e) {
      movies = [];
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('أفلام ومسلسلات'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    textInputAction: TextInputAction.search,
                    onSubmitted: _search,
                    decoration: InputDecoration(
                      hintText: 'ابحث عن فيلم أو مسلسل...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 8),
                ElevatedButton(onPressed: () => _search(_searchCtrl.text), child: Text('بحث')),
              ],
            ),
          ),
          Expanded(
            child: loading
                ? Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _load,
                    child: movies.isEmpty
                        ? ListView(children: [Center(child: Padding(padding: EdgeInsets.all(24), child: Text('لا يوجد نتائج')))])
                        : ListView.builder(
                            itemCount: movies.length,
                            itemBuilder: (ctx, i) {
                              final m = movies[i];
                              return MovieCard(
                                movie: m,
                                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailsScreen(movie: m))),
                              );
                            },
                          ),
                  ),
          ),
        ],
      ),
    );
  }
}