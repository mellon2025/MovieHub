import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../models/movie.dart';

class ApiService {
  final String _base = 'https://api.themoviedb.org/3';
  final String apiKey = dotenv.env['TMDB_API_KEY'] ?? '';

  Future<List<Movie>> fetchPopular({int page = 1}) async {
    final url = Uri.parse('$_base/movie/popular?api_key=$apiKey&language=en-US&page=$page');
    final res = await http.get(url);
    if (res.statusCode == 200) {
      final data = json.decode(res.body);
      final List results = data['results'];
      return results.map((j) => Movie.fromJson(j)).toList();
    } else {
      throw Exception('Failed to load popular movies');
    }
  }

  Future<List<Movie>> search(String query, {int page = 1}) async {
    final url = Uri.parse('$_base/search/movie?api_key=$apiKey&language=en-US&query=${Uri.encodeComponent(query)}&page=$page&include_adult=false');
    final res = await http.get(url);
    if (res.statusCode == 200) {
      final data = json.decode(res.body);
      final List results = data['results'];
      return results.map((j) => Movie.fromJson(j)).toList();
    } else {
      throw Exception('Search failed');
    }
  }

  Future<String?> fetchYoutubeTrailerKey(int movieId) async {
    final url = Uri.parse('$_base/movie/$movieId/videos?api_key=$apiKey&language=en-US');
    final res = await http.get(url);
    if (res.statusCode == 200) {
      final data = json.decode(res.body);
      final List results = data['results'];
      final yt = results.firstWhere(
        (v) => v['site'] == 'YouTube' && v['type'] == 'Trailer',
        orElse: () => null,
      );
      if (yt != null) return yt['key'];
    }
    return null;
  }
}