import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/movie.dart';

class MovieCard extends StatelessWidget {
  final Movie movie;
  final VoidCallback onTap;
  const MovieCard({required this.movie, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Card(
        child: Row(
          children: [
            movie.posterPath.isNotEmpty
                ? CachedNetworkImage(
                    imageUrl: movie.posterUrl(),
                    width: 100,
                    height: 150,
                    fit: BoxFit.cover,
                    placeholder: (c, u) => Image.asset('assets/placeholder.png', width: 100, height: 150, fit: BoxFit.cover),
                    errorWidget: (c, u, e) => Container(width: 100, height: 150, color: Colors.grey),
                  )
                : Image.asset('assets/placeholder.png', width: 100, height: 150, fit: BoxFit.cover),
            SizedBox(width: 10),
            Expanded(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(movie.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    SizedBox(height: 6),
                    Text(movie.overview, maxLines: 4, overflow: TextOverflow.ellipsis),
                    Spacer(),
                    Text(movie.releaseDate, style: TextStyle(color: Colors.grey)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}